-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 14, 2016 at 01:11 
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `WorldMineralMap`
--
CREATE DATABASE IF NOT EXISTS `WorldMineralMap` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `WorldMineralMap`;

-- --------------------------------------------------------

--
-- Table structure for table `Login`
--
-- in use(#1932 - Table 'WorldMineralMap.Login' doesn't exist in engine)
-- Error reading data: (#1932 - Table 'WorldMineralMap.Login' doesn't exist in engine)

-- --------------------------------------------------------

--
-- Table structure for table `Maps`
--
-- in use(#1932 - Table 'WorldMineralMap.Maps' doesn't exist in engine)
-- Error reading data: (#1932 - Table 'WorldMineralMap.Maps' doesn't exist in engine)

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
